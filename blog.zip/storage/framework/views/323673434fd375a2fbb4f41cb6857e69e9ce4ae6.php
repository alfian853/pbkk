<?php $__env->startSection('content'); ?>
    <div class="container"><div class="row">
            <div class="col-md-12">
            <h3>Akademik:Tabel Mahasiwa</h3>
                <div class="panel panel-default"><div class="panel-body">
                        <form action="<?php echo e(route('mhs.store')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group<?php echo e($errors->has('nrp') ? ' has-error' : ''); ?>">
                                <input type="text" name="nrp" class="form-control" placeholder="Nrp">
                                <?php echo $errors->first('nama', '<p class="help-block">:message</p>'); ?>

                            </div>
                            <div class="form-group<?php echo e($errors->has('namamhs') ? ' has-error' : ''); ?>">
                                <input type="text" name="namamhs" class="form-control" placeholder="Nama">
                                <?php echo $errors->first('nama', '<p class="help-block">:message</p>'); ?>

                            </div>

                            <div class="form-group">
                                <?php echo Form::label('nipdosenwali', 'Dosen Wali'); ?>

                                <?php echo Form::select('nipdosenwali', $dsn ,null , array('class' => 'form-control')); ?>

                            </div>
                            <div class="form-group">
                                <input type="submit" class="btn btn-primary" value="Simpan"></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>