<?php $__env->startSection('content'); ?>
    <div class="container">	<div class="row"><div class="col-md-12">
                <h3>Tabel Mahasiswa Edit</h3>
                <div class="panel panel-default"><div class="panel-body">
                        <form action="<?php echo e(route('dosen.update', $m->id)); ?>" method="post">
                            <input name="_method" type="hidden" value="PATCH">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group<?php echo e($errors->has('nip') ? ' has-error' : ''); ?>">
                                <input type="text" name="nip" class="form-control" placeholder="Nip" value="<?php echo e($m->nip); ?>">
                                <?php echo $errors->first('nip', '<p class="help-block">:message</p>'); ?>

                            </div>

                            <div class="form-group<?php echo e($errors->has('nama') ? ' has-error' : ''); ?>">
                                <input type="text" name="nama" class="form-control" placeholder="Nama" value="<?php echo e($m->nama); ?>">
                                <?php echo $errors->first('nama', '<p class="help-block">:message</p>'); ?>

                            </div>
                            <div class="form-group<?php echo e($errors->has('alamat') ? ' has-error' : ''); ?>">
                                <input type="text" name="alamat" class="form-control" placeholder="Alamat" value="<?php echo e($m->alamat); ?>">
                                <?php echo $errors->first('alamat', '<p class="help-block">:message</p>'); ?>

                            </div>
                            <div class="form-group">
                                <input type="submit" class="btn btn-primary" value="Simpan"></div>
                        </form>
                    </div></div></div></div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>