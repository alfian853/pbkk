<?php $__env->startSection('title'); ?>
    Tambah Data Dosen
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel panel-default">
        <div class="panel-body">
            <h4><i class="fa fa-plus-square">
                </i> TAMBAH Dosen</h4><hr>
            <div class="row"><div class="col-md-3">
                    <div class="list-group">
                        <a href="#" class="list-group-item active">
                            <i class="fa fa-cogs"></i> MENU Dosen  </a>
                        <a href="/dosen" class="list-group-item">
                            <i class="fa fa-refresh"></i> Tampilkan Semua</a>
                        <a href="/" class="list-group-item">
                            <i class="fa fa-home"></i> Home</a>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <?php echo Form::open(array('url' => '/dosen')); ?>

                            <div class="form-group">
                                <?php echo Form::label('nip', 'NIP'); ?>

                                <?php echo Form::text('nip',null, array('class' => 'form-control','placeholder'=>'NIP')); ?></div>
                            <div class="form-group">
                                <?php echo Form::label('namadosen', 'Nama Dosen'); ?>

                                <?php echo Form::text('namadosen', null, array('class' =>
                                    'form-control','placeholder'=>'Nama Dosen')); ?>

                            </div>
                            <?php echo Form::button('<i class="fa fa-plus-square"></i>'.
                                ' Simpan', array('type' => 'submit', 'class'
                                 => 'btn btn-primary')); ?>

                            <?php echo Form::button('<i class="fa fa-times"></i>'.
                                 ' Reset', array('type' => 'reset', 'class'
                                 => 'btn btn-danger')); ?>

                            <?php echo Form::close(); ?>

                        </div></div></div></div></div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>