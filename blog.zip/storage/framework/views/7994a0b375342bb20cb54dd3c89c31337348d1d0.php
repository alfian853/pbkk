<?php $__env->startSection('title'); ?>
    Data Dosen
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="panel panel-default">
        <div class="panel-body">
            <h4><i class="fa fa-university"></i> DAFTAR DOSEN</h4><hr>
            <div class=row><div class="col-md-6">
                    <a href="/dosen/create" class="btn btn-primary">
                        <i class="fa fa-plus-circle"></i> Tambah</a>
                </div><div class="col-md-2"></div><div class="col-md-4">            </div></div><br>
            <?php if($dsn->count()): ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped
              table-hover table-condensed tfix">
                        <thead align="center">
                        <tr><td><b>NIP</b></td><td><b>Nama DOSEN</b></td>
                            <td colspan="2"><b>MENU</b></td></tr>
                        </thead>

                        <?php $__currentLoopData = $dsn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr><td><?php echo e($m->nip); ?></td><td><?php echo e($m->namadosen); ?></td>
                                <td align="center" width="30px">
                                    <a href="/dosen/<?php echo e($m->nip); ?>/edit" class="btn btn-warning btn-sm"
                                       role="button"><i class="fa fa-pencil-square"></i> Edit</a>                           </td>
                                <td align="center" width="30px">
                                    <?php echo Form::open(array('route' => array('dosen.destroy', $m->nip),
                                                         'method' => 'delete',
                                                         'style' => 'display:inline')); ?>

                                    <button class='btn btn-sm btn-danger delete-btn' type='submit'>
                                        <i class='fa fa-times-circle'></i> Delete </button>
                                    <?php echo Form::close(); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-warning">
                    <i class="fa fa-exclamation-triangle"></i> Data Dosen tidak Ada
                </div>
            <?php endif; ?>
        </div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>