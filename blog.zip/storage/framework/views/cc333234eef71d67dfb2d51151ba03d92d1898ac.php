<?php $__env->startSection('title'); ?>
    Edit MahaSiswa
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="panel panel-default">
        <div class="panel-body">
            <h4><i class="fa fa-check-square">
                </i> EDIT MAHASISWA</h4><hr>
            <div class="row">
                <div class="col-md-3">
                    <div class="list-group">
                        <a href="#" class="list-group-item active">
                            <i class="fa fa-cogs"></i> MENU MAHASISWA
                        </a>
                        <a href="/mhs" class="list-group-item">
                            <i class="fa fa-refresh"></i> Tampilkan Semua</a>
                        <a href="/" class="list-group-item">
                            <i class="fa fa-home"></i> Home</a>
                    </div>
                </div>
                <?php echo Form::model($mhsnya,['method'=>'PATCH',
                  'action'=>['MhsController@update',$mhsnya->nrp]]); ?>

                <div class="form-group">
                    <?php echo Form::label('nrp', 'NRP'); ?>

                    <?php echo Form::text('nrp',null, array('class' => 'form-control','placeholder'=>'NRP')); ?>

                </div>
                <div class="form-group">
                    <?php echo Form::label('namamhs', 'Nama Mahasiswa'); ?>

                    <?php echo Form::text('namamhs', null, array('class' => 'form-control','placeholder'=>'Nama Mahasiswa')); ?>

                </div><div class="form-group">
                <?php echo Form::label('nipdosenwali', 'Dosen Wali'); ?>

                <?php echo Form::select('nipdosenwali', $dosennya ,null ,
                    array('class' => 'form-control')); ?>

                </div>
            </div>
            <?php echo Form::button('<i class="fa fa-check-square"></i>'. ' Update', array('type' => 'submit', 'class' => 'btn btn-primary')); ?>

            <?php echo Form::close(); ?>

        </div></div></div></div></div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>