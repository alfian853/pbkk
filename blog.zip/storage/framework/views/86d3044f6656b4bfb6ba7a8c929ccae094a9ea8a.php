<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Form</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <style>
    </style>
</head>
<body>
<div>
    <?php echo Form::open(['url' => '/form']); ?>

    <?php echo e(Form::label('num1','angka 1')); ?>

    <?php echo e(Form::number('num1', '0')); ?>

    <?php echo e(Form::select('operator',['+'=>'+','-'=>'-','/'=>'/','*'=>'*'])); ?>

    <?php echo e(Form::label('num2','angka 2')); ?>

    <?php echo e(Form::number('num2', '0')); ?>

    <?php echo e(Form::submit('post now!')); ?>

    <?php echo Form::close(); ?>

</div>
</body>
</html>
